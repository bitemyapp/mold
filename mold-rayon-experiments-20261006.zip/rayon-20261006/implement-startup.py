from pathlib import Path
root=Path('/Users/callen/.codex/worktrees/mold-rayon-startup/mold')
p=root/'vendor/rayon-core/src/lib.rs'; s=p.read_text()
needle='''    /// Creates a scoped `ThreadPool` initialized using this configuration.'''
s=s.replace(needle,'''    /// Initializes the global pool while a helper starts the worker threads.
    ///
    /// Unlike `build_global`, this returns without waiting for every worker to
    /// be spawned or primed. Work may be submitted immediately; it is queued
    /// until a worker can execute it. With `use_current_thread`, the caller can
    /// also execute work immediately. All other global-pool semantics, thread
    /// names, stack sizes and start/exit handlers are retained.
    ///
    /// Creating the helper can fail synchronously. A later worker creation
    /// failure aborts the process: after publishing the registry, Rayon cannot
    /// safely remove an unstarted worker that may already have broadcast jobs
    /// queued for it. Use `build_global` if recoverable spawn errors are needed.
    /// This experimental API is available only with the default spawn handler.
    pub fn build_global_async(self) -> Result<(), ThreadPoolBuildError> {
        // There are no workers to defer when the caller is the sole worker.
        if self.use_current_thread && self.get_num_threads() == 1 {
            return self.build_global();
        }

        let (sender, receiver) = std::sync::mpsc::channel::<ThreadBuilder>();
        std::thread::Builder::new()
            .name("rayon-startup".into())
            .spawn(move || {
                let abort = unwind::AbortIfPanic;
                for worker in receiver {
                    if let Err(error) = DefaultSpawn.spawn(worker) {
                        panic!("Rayon: failed to start a worker: {error}");
                    }
                }
                std::mem::forget(abort);
            })
            .map_err(|error| ThreadPoolBuildError::new(ErrorKind::IOError(error)))?;

        let builder = self.spawn_handler(move |worker| {
            sender.send(worker).map_err(|_| io::Error::other("Rayon startup helper exited"))
        });
        registry::init_global_registry(builder)?;
        Ok(())
    }

'''+needle,1)
p.write_text(s)
p=root/'src/driver.rs'; p.write_text(p.read_text().replace('        .build_global()','        .build_global_async()',1))
p=root/'vendor/rayon-core/Cargo.toml'; p.write_text(p.read_text()+'\n[[test]]\nname = "async_global"\npath = "tests/async_global.rs"\n\n[[test]]\nname = "async_global_one"\npath = "tests/async_global_one.rs"\n\n[[test]]\nname = "async_global_external"\npath = "tests/async_global_external.rs"\n')
(root/'vendor/rayon-core/tests/async_global.rs').write_text('''use rayon_core::{broadcast, current_num_threads, current_thread_index, join, spawn, ThreadPoolBuilder};
use std::sync::{mpsc, Arc, Barrier};
use std::time::Duration;

#[test]
fn returns_before_workers_start_and_publishes_the_global_registry() {
    let (done, receive) = mpsc::channel();
    std::thread::spawn(move || {
        let release = Arc::new(Barrier::new(4));
        let worker_release = release.clone();
        ThreadPoolBuilder::new().num_threads(4).use_current_thread()
            .thread_name(|i| format!("async-worker-{i}"))
            .stack_size(2 * 1024 * 1024)
            .start_handler(move |i| {
                assert!(i > 0);
                assert_eq!(std::thread::current().name(), Some(format!("async-worker-{i}").as_str()));
                worker_release.wait();
            })
            .build_global_async().unwrap();
        assert_eq!(current_thread_index(), Some(0));
        assert_eq!(current_num_threads(), 4);
        // All other workers are still blocked. The caller can do parallel work.
        assert_eq!(join(|| 17, || 25), (17, 25));
        let (sent, received) = mpsc::channel();
        std::thread::spawn(move || {
            assert_eq!(current_thread_index(), None);
            assert_eq!(current_num_threads(), 4);
            spawn(move || sent.send(current_thread_index().unwrap()).unwrap());
        }).join().unwrap();
        release.wait();
        assert!(received.recv_timeout(Duration::from_secs(5)).unwrap() < 4);
        assert_eq!(broadcast(|ctx| ctx.index()), vec![0, 1, 2, 3]);
        assert!(ThreadPoolBuilder::new().build_global_async().is_err());
        done.send(()).unwrap();
    });
    receive.recv_timeout(Duration::from_secs(10)).unwrap();
}
''')
(root/'vendor/rayon-core/tests/async_global_one.rs').write_text('''use rayon_core::{broadcast, current_num_threads, join, ThreadPoolBuilder};

#[test]
fn sole_current_worker_needs_no_helper() {
    std::thread::spawn(|| {
        ThreadPoolBuilder::new().num_threads(1).use_current_thread().build_global_async().unwrap();
        assert_eq!(current_num_threads(), 1);
        assert_eq!(join(|| 3, || 4), (3, 4));
        assert_eq!(broadcast(|ctx| ctx.index()), vec![0]);
    }).join().unwrap();
}
''')
(root/'vendor/rayon-core/tests/async_global_external.rs').write_text('''use rayon_core::{broadcast, current_num_threads, join, ThreadPoolBuilder};
use std::sync::{mpsc, Arc, Barrier};
use std::time::Duration;

#[test]
fn caller_outside_pool_can_submit_work_after_async_initialization() {
    let (done, receive) = mpsc::channel();
    std::thread::spawn(move || {
        let release = Arc::new(Barrier::new(3));
        let workers = release.clone();
        ThreadPoolBuilder::new().num_threads(2)
            .start_handler(move |_| { workers.wait(); })
            .build_global_async().unwrap();
        assert_eq!(current_num_threads(), 2);
        release.wait();
        assert_eq!(join(|| 19, || 23), (19, 23));
        assert_eq!(broadcast(|ctx| ctx.index()), vec![0, 1]);
        done.send(()).unwrap();
    });
    receive.recv_timeout(Duration::from_secs(10)).unwrap();
}
''')
