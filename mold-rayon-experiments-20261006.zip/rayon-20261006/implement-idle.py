from pathlib import Path
root=Path('/Users/callen/.codex/worktrees/mold-rayon-idle/mold')
p=root/'vendor/rayon-core/src/lib.rs'; s=p.read_text()
s=s.replace('    breadth_first: bool,','    breadth_first: bool,\n\n    /// How long idle workers yield and search before they may sleep.\n    idle_timeout: std::time::Duration,',1)
s=s.replace('            breadth_first: false,','            breadth_first: false,\n            idle_timeout: std::time::Duration::ZERO,',1)
s=s.replace('            breadth_first: self.breadth_first,','            breadth_first: self.breadth_first,\n            idle_timeout: self.idle_timeout,',1)
s=s.replace('            ref breadth_first,','            ref breadth_first,\n            ref idle_timeout,',1)
s=s.replace('            .field("num_threads", num_threads)','            .field("idle_timeout", idle_timeout)\n            .field("num_threads", num_threads)',1)
s=s.replace('    /// Returns a reference to the current spawn handler.','''    /// Delays parking idle workers by at least this duration while they keep
    /// searching for work and yielding the processor. This can reduce wake-up
    /// latency between short bursts of parallel work, at the cost of CPU time.
    ///
    /// Zero (the default) retains Rayon's normal round-based sleep policy.
    /// This is a minimum idle period before parking, not a scheduling deadline;
    /// a worker may take longer to park if it is descheduled or new work arrives.
    pub fn idle_timeout(mut self, timeout: std::time::Duration) -> Self {
        self.idle_timeout = timeout;
        self
    }

    /// Returns a reference to the current spawn handler.''',1)
p.write_text(s)
p=root/'vendor/rayon-core/src/registry.rs'; p.write_text(p.read_text().replace('Sleep::new(n_threads)','Sleep::new(n_threads, builder.idle_timeout)',1))
p=root/'vendor/rayon-core/src/sleep/mod.rs'; s=p.read_text()
s=s.replace('use std::thread;','use std::thread;\nuse std::time::{Duration, Instant};',1)
s=s.replace('    counters: AtomicCounters,','    counters: AtomicCounters,\n    idle_timeout: Duration,',1)
s=s.replace('    rounds: u32,','    rounds: u32,\n\n    /// Avoid clock reads altogether when the idle timeout is disabled.\n    idle_since: Option<Instant>,',1)
s=s.replace('fn new(n_threads: usize) -> Sleep','fn new(n_threads: usize, idle_timeout: Duration) -> Sleep',1)
s=s.replace('            counters: AtomicCounters::new(),','            counters: AtomicCounters::new(),\n            idle_timeout,',1)
s=s.replace('            rounds: 0,','            rounds: 0,\n            idle_since: (!self.idle_timeout.is_zero()).then(Instant::now),',1)
s=s.replace('        if idle_state.rounds < ROUNDS_UNTIL_SLEEPY {','''        // Extend only the pre-sleep search. The existing sleepy announcement,
        // job-event counter, latch and condition-variable protocol is unchanged.
        if idle_state.rounds == ROUNDS_UNTIL_SLEEPY
            && idle_state
                .idle_since
                .is_some_and(|since| since.elapsed() < self.idle_timeout)
        {
            thread::yield_now();
            return;
        }
        if idle_state.rounds < ROUNDS_UNTIL_SLEEPY {''',1)
s=s.replace('        self.rounds = 0;','        self.rounds = 0;\n        if self.idle_since.is_some() {\n            self.idle_since = Some(Instant::now());\n        }',1)
p.write_text(s)
p=root/'src/driver.rs'; p.write_text(p.read_text().replace('        .num_threads(threads)','        .num_threads(threads)\n        .idle_timeout(std::time::Duration::from_millis(2))',1))
p=root/'vendor/rayon-core/Cargo.toml'; p.write_text(p.read_text()+'\n[[test]]\nname = "idle_timeout"\npath = "tests/idle_timeout.rs"\n')
(root/'vendor/rayon-core/tests/idle_timeout.rs').write_text('''use rayon_core::{broadcast, join, scope, ThreadPoolBuilder};
use std::sync::{mpsc, Arc, Barrier};
use std::time::Duration;

#[test]
fn bursts_nested_work_broadcast_and_shutdown() {
    for threads in [1, 2, 4] {
        for timeout in [Duration::ZERO, Duration::from_millis(2)] {
            let (finished, receive) = mpsc::channel();
            std::thread::spawn(move || {
                let (exited, exits) = mpsc::channel();
                let pool = ThreadPoolBuilder::new()
                    .num_threads(threads)
                    .idle_timeout(timeout)
                    .exit_handler(move |_| { exited.send(()).unwrap(); })
                    .build().unwrap();
                for _ in 0..8 {
                    let barrier = Arc::new(Barrier::new(threads));
                    let values = pool.install(|| broadcast(|ctx| {
                        barrier.wait();
                        join(|| ctx.index() + 1, || 7)
                    }));
                    assert_eq!(values.len(), threads);
                    assert_eq!(values.iter().map(|x| x.0).sum::<usize>(), threads * (threads + 1) / 2);
                    pool.install(|| scope(|s| {
                        let values = &values;
                        s.spawn(move |_| assert!(values.iter().all(|x| x.1 == 7)));
                    }));
                    // Exercise both the polling period and wake-up after parking.
                    std::thread::sleep(Duration::from_millis(8));
                }
                drop(pool);
                for _ in 0..threads { exits.recv_timeout(Duration::from_secs(5)).unwrap(); }
                finished.send(()).unwrap();
            });
            receive.recv_timeout(Duration::from_secs(10)).unwrap();
        }
    }
}
''')
