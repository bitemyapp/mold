//! Merged sections: constant pools such as string literals, deduplicated
//! across all input files.
//!
//! Fragments are deduplicated through a concurrent hash table sized for
//! 2/3 occupancy from an estimate of their number, and the output layout
//! follows the table: shard by shard, in the deterministic bucket order
//! of [`FrozenMap::sorted_entries`].

use std::borrow::Cow;
use std::ffi::OsStr;
use std::sync::RwLock;
use std::sync::atomic::Ordering;

use bstr::BStr;
use rayon::prelude::*;

use crate::arch::Target;
use crate::chunks::ChunkHeader;
use crate::cmdline::Args;
use crate::context::Context;
use crate::elf::*;
use crate::input_files::display_file;
use crate::input_sections::{MergeInfo, SectionFragment, SectionRef};
use crate::out;
use crate::output_file::split_at_offsets;
use crate::util::align_to;
use crate::util::concurrent_map::{ConcurrentMap, EntryId, FrozenMap, NUM_SHARDS};
use crate::util::hyperloglog::HyperLogLog;
use crate::util::perf::Timers;

/// Index of a merged section in `Context::merged_sections`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct MergedSectionId(pub u32);

impl MergedSectionId {
    pub fn index(self) -> usize {
        self.0 as usize
    }
}

/// A conversion worker's bounded cache. Keys are copied because the shared
/// section vector can move as other workers add sections; IDs remain stable.
#[derive(Default)]
pub struct MergedSectionCache {
    entries: Vec<(MergedSectionKey<'static>, MergedSectionId)>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
struct MergedSectionKey<'a> {
    name: &'a BStr,
    flags: u64,
    sh_type: u32,
    entsize: u64,
}

/// The deterministically ordered fragments and the two output sizes of one
/// hash-table shard.
#[derive(Debug)]
struct ShardLayout {
    near_size: u64,
    far_size: u64,
    fragments: Vec<EntryId>,
}

// MergedSection represents an output section containing a constant pool such
// as string literals or floating-point constants.
#[derive(Debug)]
pub struct MergedSection<E: Target> {
    pub hdr: ChunkHeader<E>,

    /// The input sections merged into this one.
    pub members: Vec<SectionRef>,

    /// The fragment map while fragments are being inserted.
    pub map: ConcurrentMap<SectionFragment>,

    /// The fragments once insertion is done.
    pub fragments: FrozenMap<SectionFragment>,
    pub estimation: u64,
    pub resolved: bool,

    /// The fragments in deterministic order within each hash-table shard.
    shards: Vec<ShardLayout>,

    /// Starts of the 32-bit and unrestricted halves of every shard, followed
    /// by the section size.
    shard_offsets: Vec<u64>,
}

/// A direct reference to one input member while allocated merged sections
/// are resolved in parallel. C++ mold keeps the same pointers in
/// `MergedSection::members`; Rust keeps the durable section references there
/// and borrows the stable objects directly for this phase.
pub struct ResolveMember<'a> {
    pub merge_info: &'a mut MergeInfo,
    pub data: &'static [u8],
    pub filename: &'a str,
    pub archive_name: &'a std::path::Path,
    pub name: &'static BStr,
}

pub struct ResolveOptions<'a> {
    pub allocated_only: bool,
    pub gc_sections: bool,
    pub comment: Option<MergedSectionId>,
    pub cmdline_args: &'a [Cow<'static, OsStr>],
    pub timers: &'a Timers,
}

fn merged_output_name(
    args: &Args,
    name: &'static BStr,
    flags: u64,
    entsize: u64,
    addralign: u64,
) -> Cow<'static, [u8]> {
    if args.relocatable && !args.relocatable_merge_sections {
        return Cow::Borrowed(name);
    }
    if !args.unique.is_empty() && args.unique.find(name) != -1 {
        return Cow::Borrowed(name);
    }

    // GCC seems to create sections named ".rodata.strN.<mangled-symbol-name>.M"
    // or ".rodata.cst.<mangled-symbol-name>.cstN". We want to eliminate the
    // symbol name part from the section name.
    if name.starts_with(b".rodata.") {
        let name2 = if flags & SHF_STRINGS as u64 != 0 {
            format!(".rodata.str{entsize}.{addralign}")
        } else {
            format!(".rodata.cst{entsize}")
        };
        if name == name2.as_bytes() {
            return Cow::Borrowed(name);
        }
        return Cow::Owned(name2.into_bytes());
    }
    Cow::Borrowed(name)
}

impl<E: Target> MergedSection<E> {
    fn new(name: &'static BStr, flags: u64, sh_type: u32, entsize: u64) -> Self {
        let mut hdr = ChunkHeader::<E>::with_name(name, sh_type, flags);
        hdr.shdr.sh_entsize.set(entsize);
        Self {
            hdr,
            members: Vec::new(),
            map: ConcurrentMap::default(),
            fragments: FrozenMap::default(),
            estimation: 0,
            resolved: false,
            shards: Vec::new(),
            shard_offsets: Vec::new(),
        }
    }

    /// Finds or creates the merged section an input section belongs to.
    /// Files are converted in parallel, and nearly every lookup finds an
    /// existing section, so the list is only write-locked to add one.
    pub fn get_instance(
        args: &Args,
        sections: &RwLock<Vec<Self>>,
        name: &'static BStr,
        shdr: &ElfShdr<E>,
        cache: &mut MergedSectionCache,
    ) -> Option<MergedSectionId> {
        let sh_flags = shdr.sh_flags.get();
        if sh_flags & SHF_MERGE as u64 == 0 {
            return None;
        }
        let addralign = shdr.sh_addralign.get().max(1);
        let flags = sh_flags & !(SHF_GROUP as u64) & !(SHF_COMPRESSED as u64);
        let mut entsize = shdr.sh_entsize.get();
        if entsize == 0 {
            entsize = if sh_flags & SHF_STRINGS as u64 != 0 { 1 } else { shdr.sh_addralign.get() };
        }
        if entsize == 0 {
            return None;
        }

        let name = merged_output_name(args, name, flags, entsize, addralign);
        let sh_type = shdr.sh_type.get();
        let key = MergedSectionKey { name: BStr::new(&name), flags, sh_type, entsize };
        if let Some((_, id)) = cache.entries.iter().find(|(k, _)| *k == key) {
            return Some(*id);
        }
        let mut remember = |id, name: &'static BStr| {
            // Bound lookup cost even when --unique creates many sections.
            if cache.entries.len() < 32 {
                let key = MergedSectionKey { name, flags, sh_type, entsize };
                cache.entries.push((key, id));
            }
            Some(id)
        };
        let find = |sections: &[Self]| {
            sections
                .iter()
                .enumerate()
                .find(|(_, s)| {
                    s.hdr.name == name.as_ref()
                        && s.hdr.shdr.sh_flags.get() == flags
                        && s.hdr.shdr.sh_type.get() == sh_type
                        && s.hdr.shdr.sh_entsize.get() == entsize
                })
                .map(|(i, s)| (MergedSectionId(i as u32), s.hdr.name))
        };

        // Search for an existing output section.
        if let Some((id, name)) = find(&sections.read().unwrap()) {
            return remember(id, name);
        }

        // Create a new output section.
        let mut sections = sections.write().unwrap();
        if let Some((id, name)) = find(&sections) {
            return remember(id, name);
        }
        // Only a new section needs to retain its generated name permanently.
        let name = BStr::new(match name {
            Cow::Borrowed(name) => name,
            Cow::Owned(name) => crate::util::leak_bytes(name),
        });
        sections.push(Self::new(name, flags, sh_type, entsize));
        remember(MergedSectionId(sections.len() as u32 - 1), name)
    }

    pub fn insert(
        &self,
        data: &'static [u8],
        hash: u64,
        p2align: u8,
        gc_sections: bool,
    ) -> EntryId {
        // Even if GC is enabled, we garbage-collect only memory-mapped strings.
        // Non-memory-allocated strings are typically identifiers used by debug info.
        // To remove such strings, use the `strip` command.
        let is_alive = !gc_sections || !self.is_alloc();
        let (id, frag, _) = self.map.insert_with(data, hash, || SectionFragment::new(is_alive));
        // Most insertions find the fragment there already, so the alignment
        // is only written when it grows: an atomic update on every insertion
        // would bounce the cache line of a popular fragment between cores.
        if frag.p2align.load(Ordering::Relaxed) < p2align {
            frag.p2align.fetch_max(p2align, Ordering::Relaxed);
        }
        id
    }

    pub fn is_alloc(&self) -> bool {
        self.hdr.shdr.sh_flags.get() & SHF_ALLOC as u64 != 0
    }
}

/// Splits the members into fragments and deduplicates them.
pub fn resolve<E: Target>(ctx: &mut Context<E>, id: MergedSectionId) {
    let Context { objs, merged_sections, args, timers, .. } = ctx;
    let msec = &merged_sections[id.index()];
    let gc_sections = args.gc_sections;

    // The members, by file: a file's sections are worked on by one task.
    let mut member_shndx: Vec<Vec<u32>> = vec![Vec::new(); objs.pool_len()];
    for m in &msec.members {
        member_shndx[m.file.index()].push(m.shndx);
    }

    // Split the members into pieces, estimating the number of distinct
    // ones to size the table.
    let t = timers.start("split_contents");
    let estimate = objs
        .par_iter_mut()
        .filter_map(|file| {
            let shndx = &member_shndx[file.id().index()];
            (!shndx.is_empty()).then_some((file, shndx))
        })
        .fold(HyperLogLog::default, |mut sketch, (file, shndx)| {
            let mut slots = std::mem::take(&mut file.sections);
            for &i in shndx {
                let (m, isec) =
                    slots.merge_info_with_section_mut(i as usize).expect("a mergeable section");
                let name = isec.name(file);
                m.split_contents::<E>(file, isec.contents(), name, msec, &mut sketch);
            }
            file.sections = slots;
            sketch
        })
        .reduce(HyperLogLog::default, |a, b| a.merged(&b));
    drop(t);

    // We aim for a 2/3 occupancy ratio
    let t = timers.start("resize");
    let msec = &mut merged_sections[id.index()];
    msec.estimation = estimate.cardinality();
    msec.map = ConcurrentMap::with_capacity(msec.estimation as usize * 3 / 2);
    let msec = &*msec;
    drop(t);

    let t = timers.start("resolve_contents");
    objs.par_iter_mut()
        .filter_map(|file| {
            let shndx = &member_shndx[file.id().index()];
            (!shndx.is_empty()).then_some((file, shndx))
        })
        .for_each(|(file, shndx)| {
            for &i in shndx {
                let (m, isec) = file
                    .sections
                    .merge_info_with_section_mut(i as usize)
                    .expect("a mergeable section");
                m.resolve_contents(isec.contents(), msec, gc_sections);
            }
        });
    drop(t);

    if ctx.comment == Some(id) {
        let msec = &ctx.merged_sections[id.index()];
        add_comment_strings(msec, ctx.args.gc_sections, &ctx.cmdline_args);
    }

    // Compute section alignment
    let msec = &ctx.merged_sections[id.index()];
    let p2align = msec
        .members
        .iter()
        .filter_map(|m| ctx.objs[m.file.index()].merge_info(m.shndx as usize))
        .map(|m| m.p2align)
        .max()
        .unwrap_or(0);

    let msec = &mut ctx.merged_sections[id.index()];
    msec.hdr.shdr.sh_addralign.set(1 << p2align);
    msec.fragments = std::mem::take(&mut msec.map).freeze();
    msec.resolved = true;
    if !msec.is_alloc() {
        layout(msec);
    }
}

/// Resolves selected merged sections concurrently, as C++ mold does.
/// Direct member borrows let different parent sections mutate disjoint
/// `MergeInfo`s even when they belong to the same object file.
pub fn resolve_sections<E: Target>(
    sections: &mut [MergedSection<E>],
    members: &mut [Vec<ResolveMember<'_>>],
    options: ResolveOptions<'_>,
) {
    let ResolveOptions { allocated_only, gc_sections, comment, cmdline_args, timers } = options;
    let workers = rayon::current_num_threads();
    let bytes: usize = sections
        .iter()
        .zip(members.iter())
        .filter(|(section, _)| !section.resolved && (!allocated_only || section.is_alloc()))
        .flat_map(|(_, members)| members.iter())
        .map(|member| member.data.len())
        .sum();
    // Fixed ownership trades work stealing for reuse of the fragment metadata
    // created by the preceding split pass. Amortize its setup on large inputs.
    if workers > 1 && bytes >= 8 * 1024 * 1024 {
        static LOCAL_BYTES: crate::util::perf::Counter =
            crate::util::perf::Counter::new("local_merge_bytes");
        LOCAL_BYTES.add(bytes as i64);
        resolve_with_local_ownership(sections, members, allocated_only, gc_sections, timers);
    } else {
        let t = timers.start("split_contents");
        let estimates: Vec<Option<HyperLogLog>> = sections
            .par_iter()
            .zip(members.par_iter_mut())
            .map(|(section, members)| {
                (!section.resolved && (!allocated_only || section.is_alloc())).then(|| {
                    members
                        .par_iter_mut()
                        .fold(HyperLogLog::default, |mut sketch, member| {
                            member.merge_info.split_contents::<E>(
                                &display_file(member.filename, member.archive_name),
                                member.data,
                                member.name,
                                section,
                                &mut sketch,
                            );
                            sketch
                        })
                        .reduce(HyperLogLog::default, |a, b| a.merged(&b))
                })
            })
            .collect();
        drop(t);

        // We aim for a 2/3 occupancy ratio
        let t = timers.start("resize");
        sections.par_iter_mut().zip(&estimates).for_each(|(section, estimate)| {
            if let Some(estimate) = estimate {
                section.estimation = estimate.cardinality();
                section.map = ConcurrentMap::with_capacity(section.estimation as usize * 3 / 2);
            }
        });
        drop(t);

        let t = timers.start("resolve_contents");
        sections
            .par_iter()
            .zip(members.par_iter_mut())
            .filter(|(section, _)| !section.resolved && (!allocated_only || section.is_alloc()))
            .for_each(|(section, members)| {
                members.par_iter_mut().for_each(|member| {
                    member.merge_info.resolve_contents(member.data, section, gc_sections);
                });
            });
        drop(t);
    }

    sections
        .par_iter_mut()
        .zip(members.par_iter())
        .enumerate()
        .filter(|(_, (section, _))| !section.resolved && (!allocated_only || section.is_alloc()))
        .for_each(|(i, (section, members))| {
            if comment == Some(MergedSectionId(i as u32)) {
                add_comment_strings(section, gc_sections, cmdline_args);
            }

            // Compute section alignment
            let p2align = members.iter().map(|member| member.merge_info.p2align).max().unwrap_or(0);
            section.hdr.shdr.sh_addralign.set(1 << p2align);
            section.fragments = std::mem::take(&mut section.map).freeze();
            section.resolved = true;
            if !section.is_alloc() {
                layout(section);
            }
        });
}

/// Runs both member passes with identical ownership. The only redistributed
/// values are at most one contiguous member range per section and worker;
/// fragment bytes, hashes, and offsets stay in their original allocations.
fn resolve_with_local_ownership<E: Target>(
    sections: &mut [MergedSection<E>],
    members: &mut [Vec<ResolveMember<'_>>],
    allocated_only: bool,
    gc_sections: bool,
    timers: &Timers,
) {
    use std::sync::Mutex;
    let t = timers.start("assign_merge_workers");
    let workers = rayon::current_num_threads();
    let mut jobs: Vec<Vec<(usize, &mut [ResolveMember<'_>])>> =
        (0..workers).map(|_| Vec::new()).collect();
    let mut estimates: Vec<Option<HyperLogLog>> = sections
        .iter()
        .map(|section| {
            (!section.resolved && (!allocated_only || section.is_alloc()))
                .then(HyperLogLog::default)
        })
        .collect();
    for (id, members) in members.iter_mut().enumerate() {
        if estimates[id].is_none() {
            continue;
        }
        let mut bytes: usize = members.iter().map(|member| member.data.len()).sum();
        let mut remaining = members.as_mut_slice();
        for (worker, jobs) in jobs.iter_mut().enumerate() {
            if remaining.is_empty() {
                break;
            }
            let target =
                if worker + 1 == workers { usize::MAX } else { bytes.div_ceil(workers - worker) };
            let mut end = 0;
            let mut size = 0;
            while end < remaining.len() && (end == 0 || size < target) {
                size += remaining[end].data.len();
                end += 1;
            }
            let part = remaining.split_off_mut(..end).unwrap();
            jobs.push((id, part));
            bytes -= size;
        }
        debug_assert!(remaining.is_empty());
    }
    // Each mutex is acquired only by its matching broadcast worker. There is
    // no nested Rayon work or worker-local guard while a job slot is held.
    let jobs: Vec<_> = jobs.into_iter().map(Mutex::new).collect();
    drop(t);

    let t = timers.start("split_contents");
    let parts = rayon::broadcast(|worker| {
        let mut jobs = jobs[worker.index()].lock().unwrap();
        jobs.iter_mut()
            .map(|(id, members)| {
                let mut sketch = HyperLogLog::default();
                for member in members.iter_mut() {
                    member.merge_info.split_contents::<E>(
                        &display_file(member.filename, member.archive_name),
                        member.data,
                        member.name,
                        &sections[*id],
                        &mut sketch,
                    );
                }
                (*id, sketch)
            })
            .collect::<Vec<_>>()
    });
    for (id, sketch) in parts.into_iter().flatten() {
        let estimate = estimates[id].take().unwrap();
        estimates[id] = Some(estimate.merged(&sketch));
    }
    drop(t);

    let t = timers.start("resize");
    sections.par_iter_mut().zip(&estimates).for_each(|(section, estimate)| {
        if let Some(estimate) = estimate {
            section.estimation = estimate.cardinality();
            section.map = ConcurrentMap::with_capacity(section.estimation as usize * 3 / 2);
        }
    });
    drop(t);

    let t = timers.start("resolve_contents");
    rayon::broadcast(|worker| {
        let mut jobs = jobs[worker.index()].lock().unwrap();
        for (id, members) in jobs.iter_mut() {
            for member in members.iter_mut() {
                member.merge_info.resolve_contents(member.data, &sections[*id], gc_sections);
            }
        }
    });
    drop(t);
}

// Add strings to .comment
fn add_comment_strings<E: Target>(
    msec: &MergedSection<E>,
    gc_sections: bool,
    cmdline_args: &[Cow<'static, OsStr>],
) {
    let add = |mut bytes: Vec<u8>| {
        bytes.push(0);
        let data = crate::util::leak_bytes(bytes);
        msec.insert(data, xxhash_rust::xxh3::xxh3_64(data), 0, gc_sections);
    };
    // Add an identification string to .comment.
    add(crate::cmdline::VERSION.as_bytes().to_vec());

    // Embed command line arguments for debugging.
    if std::env::var_os("MOLD_DEBUG").is_some_and(|v| !v.is_empty()) {
        let mut bytes = b"mold command line: ".to_vec();
        for (i, arg) in cmdline_args[1..].iter().enumerate() {
            if i != 0 {
                bytes.push(b' ');
            }
            bytes.extend_from_slice(arg.as_encoded_bytes());
        }
        add(bytes);
    }
}

/// Lays out the live fragments and computes the section size.
pub fn compute_section_size<E: Target>(ctx: &mut Context<E>, id: MergedSectionId) {
    if !ctx.merged_sections[id.index()].resolved {
        resolve(ctx, id);
    }
    if ctx.merged_sections[id.index()].is_alloc() {
        layout(&mut ctx.merged_sections[id.index()]);
    }
}

/// Lays out one resolved merged section. Different merged sections have no
/// shared mutable state, so callers can run this for all of them in parallel.
pub fn layout<E: Target>(msec: &mut MergedSection<E>) {
    debug_assert!(msec.resolved);
    let frags = &msec.fragments;

    // Within a shard, fragments that must be reachable with 32-bit
    // relocations come first; the 32-bit halves of all shards precede the
    // other halves.
    let shards: Vec<ShardLayout> = (0..NUM_SHARDS)
        .into_par_iter()
        .map(|shard| {
            let fragments = frags.sorted_entries(shard);
            let mut near_size = 0;
            let mut far_size = 0;
            for &entry in &fragments {
                let frag = frags.get(entry);
                if !frag.is_alive() {
                    continue;
                }
                if frag.is_32bit() {
                    near_size = align_to(near_size, 1 << frag.p2align.load(Ordering::Relaxed));
                    frag.set_offset(near_size);
                    near_size += frags.key(entry).len() as u64;
                } else {
                    far_size = align_to(far_size, 1 << frag.p2align.load(Ordering::Relaxed));
                    frag.set_offset(far_size);
                    far_size += frags.key(entry).len() as u64;
                }
            }
            ShardLayout { near_size, far_size, fragments }
        })
        .collect();

    let addralign = msec.hdr.shdr.sh_addralign.get();
    let mut shard_offsets = Vec::with_capacity(NUM_SHARDS * 2 + 1);
    shard_offsets.push(0);
    for size in
        shards.iter().map(|shard| shard.near_size).chain(shards.iter().map(|shard| shard.far_size))
    {
        shard_offsets.push(align_to(shard_offsets.last().copied().unwrap() + size, addralign));
    }

    shards.par_iter().enumerate().for_each(|(i, shard)| {
        for &entry in &shard.fragments {
            let frag = frags.get(entry);
            if frag.is_alive() {
                let base =
                    if frag.is_32bit() { shard_offsets[i] } else { shard_offsets[i + NUM_SHARDS] };
                frag.set_offset(frag.offset() + base);
            }
        }
    });

    let size = shard_offsets.last().copied().unwrap();
    msec.hdr.shdr.sh_size.set(size);
    msec.shards = shards;
    msec.shard_offsets = shard_offsets;
}

pub fn write_to<E: Target>(ctx: &Context<E>, id: MergedSectionId, buf: &mut [u8]) {
    let msec = &ctx.merged_sections[id.index()];
    let frags = &msec.fragments;

    // There might be gaps between strings to satisfy alignment requirements.
    // If that's the case, we need to zero-clear them.
    let has_gaps = msec.hdr.shdr.sh_addralign.get() > 1
        && msec.hdr.shdr.sh_addralign.get() != msec.hdr.shdr.sh_entsize.get();

    // Layout gave each shard one region for its 32-bit fragments and one
    // for the rest, so each shard writes only its two regions.
    let offsets = &msec.shard_offsets;
    let mut regions = split_at_offsets(buf, &offsets[..NUM_SHARDS * 2]);
    let (near, far) = regions.split_at_mut(NUM_SHARDS);
    msec.shards.par_iter().enumerate().zip(near).zip(far).for_each(|(((i, shard), near), far)| {
        if has_gaps {
            near.fill(0);
            far.fill(0);
        }
        for &entry in &shard.fragments {
            let frag = frags.get(entry);
            if frag.is_alive() {
                let key = frags.key(entry);
                let (region, base) = if frag.is_32bit() {
                    (&mut **near, offsets[i])
                } else {
                    (&mut **far, offsets[i + NUM_SHARDS])
                };
                let start = (frag.offset() - base) as usize;
                region[start..start + key.len()].copy_from_slice(key);
            }
        }
    });
}

pub fn print_stats<E: Target>(msec: &MergedSection<E>) {
    out!("{} estimation={} actual={}", msec.hdr.name, msec.estimation, msec.fragments.len());
}
