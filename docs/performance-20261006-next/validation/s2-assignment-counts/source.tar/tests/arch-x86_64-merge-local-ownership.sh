#!/usr/bin/env bash
. $(dirname $0)/common.inc

# More than 8 MiB of mergeable input enables stable ownership. There are fewer
# members than workers in the last run; every input must still be processed.
for i in $(seq 1 8); do
  cat <<EOF | $CC -c -xassembler -o $t/$i.o -
.section .debug_str,"MS",@progbits,1
.rept 65536
.asciz "stable-input-locality-$i"
.endr
EOF
done
echo '.globl _start; _start: .byte 0' | $CC -c -xassembler -o $t/start.o -
./mold --threads=1 --build-id=sha256 -o $t/serial $t/*.o
for threads in 2 8 32; do
  ./mold --threads=$threads --build-id=sha256 -o $t/parallel $t/*.o
  cmp $t/serial $t/parallel
done
