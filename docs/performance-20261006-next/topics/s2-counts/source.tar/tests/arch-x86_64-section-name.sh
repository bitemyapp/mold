#!/usr/bin/env bash
. $(dirname $0)/common.inc

cat <<'EOF' | $CC -o $t/a.o -c -x assembler -
.globl _start
.text
_start:
  ret

.section .text.hot
.ascii ".text.hot "
.section .text.hot.foo
.ascii ".text.hot.foo "

.section .text.unknown
.ascii ".text.unknown "
.section .text.unknown.foo
.ascii ".text.unknown.foo "

.section .text.unlikely
.ascii ".text.unlikely "
.section .text.unlikely.foo
.ascii ".text.unlikely.foo "

.section .text.startup
.ascii ".text.startup "
.section .text.startup.foo
.ascii ".text.startup.foo "

.section .text.exit
.ascii ".text.exit "
.section .text.exit.foo
.ascii ".text.exit.foo "

.section .text
.ascii ".text "
.section .text.foo
.ascii ".text.foo "

.section .data.rel.ro
.ascii ".data.rel.ro "
.section .data.rel.ro.foo
.ascii ".data.rel.ro.foo "

.section .data
.ascii ".data "
.section .data.foo
.ascii ".data.foo "

.section .rodata
.ascii ".rodata "
.section .rodata.foo
.ascii ".rodata.foo "

.section .srodata
.ascii ".srodata "
.section .srodata.foo
.ascii ".srodata.foo "
EOF

./mold -o $t/exe $t/a.o -z keep-text-section-prefix

readelf -p .text.hot $t/exe | grep -F '.text.hot .text.hot.foo'
readelf -p .text.unknown $t/exe | grep -F '.text.unknown .text.unknown.foo'
readelf -p .text.unlikely $t/exe | grep -F '.text.unlikely .text.unlikely.foo'
readelf -p .text.startup $t/exe | grep -F '.text.startup .text.startup.foo'
readelf -p .text.exit $t/exe | grep -F '.text.exit .text.exit.foo'
readelf -p .text $t/exe | grep -F '.text .text.foo'
readelf -p .data.rel.ro $t/exe | grep -F '.data.rel.ro .data.rel.ro.foo'
readelf -p .data $t/exe | grep -F '.data .data.foo'
readelf -p .rodata $t/exe | grep -F '.rodata .rodata.foo'
readelf -p .srodata $t/exe | grep -F '.srodata .srodata.foo'

./mold -o $t/exe $t/a.o
readelf --sections $t/exe | not grep -F .text.hot

./mold -o $t/exe $t/a.o -z nokeep-text-section-prefix
readelf --sections $t/exe | not grep -F .text.hot
