//! Output chunks: the contiguous regions that make up the output file.
//!
//! Besides the output sections built from input sections, the linker
//! synthesizes many sections of its own (`.got`, `.plt`, `.dynamic`,
//! `.symtab` and so on). Every such section has a [`ChunkHeader`] holding
//! its section header and bookkeeping, and is addressed by a [`ChunkId`].
//! Operations common to all chunks dispatch on the id.

pub mod arm_exidx;
pub mod build_id;
pub mod comdat_group;
pub mod compressed;
pub mod copyrel;
pub mod dynamic;
pub mod dynstr;
pub mod dynsym;
pub mod eh_frame;
pub mod eh_frame_hdr;
pub mod eh_frame_reloc;
pub mod gnu_debuglink;
pub mod gnu_hash;
pub mod got;
pub mod gotplt;
pub mod hash;
pub mod interp;
pub mod merged;
pub mod note_package;
pub mod note_property;
pub mod opd;
pub mod output_section;
pub mod plt;
pub mod pltgot;
pub mod ppc64_save_restore;
pub mod reldyn;
pub mod reloc;
pub mod relplt;
pub mod relrdyn;
pub mod relro_padding;
pub mod riscv_attributes;
pub mod sframe;
pub mod sframe_reloc;
pub mod shstrtab;
pub mod strtab;
pub mod symtab;
pub mod symtab_shndx;
pub mod verdef;
pub mod verneed;
pub mod versym;

use std::num::NonZeroU32;

use bstr::BStr;

use crate::arch::Target;
use crate::context::Context;
use crate::elf::*;
use crate::input_files::{FileId, SymtabBlock};
use crate::tls;
use crate::{error, warn};

pub use merged::MergedSectionId;

/// Index of an output section in `Context::output_sections`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct OutputSectionId(NonZeroU32);

impl OutputSectionId {
    #[inline]
    pub fn new(index: u32) -> Self {
        Self(index.checked_add(1).and_then(NonZeroU32::new).expect("too many output sections"))
    }

    #[inline]
    pub fn index(self) -> usize {
        (self.0.get() - 1) as usize
    }
}

/// Identifies a chunk of the output file.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum ChunkId {
    Ehdr,
    Phdr,
    Shdr,
    Interp,
    Got,
    GotPlt,
    RelPlt,
    RelDyn,
    RelrDyn,
    Dynamic,
    Strtab,
    Dynstr,
    Hash,
    GnuHash,
    GnuDebuglink,
    Shstrtab,
    Plt,
    PltGot,
    Symtab,
    SymtabShndx,
    Dynsym,
    EhFrame,
    EhFrameHdr,
    EhFrameReloc,
    SFrame,
    SFrameReloc,
    Copyrel,
    CopyrelRelro,
    Versym,
    Verneed,
    Verdef,
    BuildId,
    NotePackage,
    NoteProperty,
    RiscvAttributes,
    ArmExidx,
    Ppc64SaveRestore,
    Ppc64Opd,
    GdbIndex,
    RelroPadding,
    Output(OutputSectionId),
    Merged(MergedSectionId),
    Reloc(u32),
    ComdatGroup(u32),
    Compressed(u32),
    /// A section of the main output that a separate debug file lists
    /// without contents.
    Placeholder(u32),
}

impl ChunkId {
    /// Whether the chunk is one of the ELF headers rather than a section.
    pub fn is_header(self) -> bool {
        matches!(self, Self::Ehdr | Self::Phdr | Self::Shdr)
    }

    pub fn as_output_section(self) -> Option<OutputSectionId> {
        match self {
            Self::Output(id) => Some(id),
            _ => None,
        }
    }
}

// Chunk represents a contiguous region in an output file.
#[derive(Debug)]
pub struct ChunkHeader<E: Target> {
    pub name: &'static BStr,
    pub shdr: ElfShdr<E>,

    /// Index in the output section header table; 0 for headers.
    pub shndx: u32,

    pub num_dynrels: u64,
    pub num_relrs: u64,
    pub relr: Vec<u64>,
    pub is_relro: bool,

    /// Some synthetic sections add local symbols to the output. For
    /// example, range extension thunks add a function_name@thunk symbol
    /// for each thunk entry. The following members are used for such
    /// synthesized symbols.
    pub local_symtab_idx: u32,
    pub num_local_symtab: u32,
    pub strtab_size: u64,
    pub strtab_offset: u64,

    /// For --section-order
    pub sect_order: i64,
}

impl<E: Target> ChunkHeader<E> {
    pub fn new(name: &'static str, sh_type: u32, sh_flags: u64) -> Self {
        Self {
            name: BStr::new(name.as_bytes()),
            shdr: {
                let mut shdr = ElfShdr::<E>::default();
                shdr.sh_type.set(sh_type);
                shdr.sh_flags.set(sh_flags);
                shdr.sh_addralign.set(1);
                shdr
            },
            shndx: 0,
            num_dynrels: 0,
            num_relrs: 0,
            relr: Vec::new(),
            is_relro: false,
            local_symtab_idx: 0,
            num_local_symtab: 0,
            strtab_size: 0,
            strtab_offset: 0,
            sect_order: 0,
        }
    }

    pub fn with_name(name: &'static BStr, sh_type: u32, sh_flags: u64) -> Self {
        Self { name, ..Self::new("", sh_type, sh_flags) }
    }

    pub fn is_alloc(&self) -> bool {
        self.shdr.sh_flags.get() & SHF_ALLOC as u64 != 0
    }
}

// ELF header which is at the beginning of each ELF file.
pub fn new_ehdr<E: Target>(sh_flags: u64) -> ChunkHeader<E> {
    let mut hdr = ChunkHeader::<E>::new("EHDR", 0, sh_flags);
    hdr.shdr.sh_size.set(size_of::<ElfEhdr<E>>() as u64);
    hdr.shdr.sh_addralign.set(E::WORD_SIZE as u64);
    hdr
}

// The section header table is usually
// located at the end of an ELF file and is optional for executables.
// Executables work without it because the runtime only reads the program
// header. Section header is significant only in object files and not
// needed at runtime
pub fn new_shdr<E: Target>() -> ChunkHeader<E> {
    let mut hdr = ChunkHeader::<E>::new("SHDR", 0, 0);
    hdr.shdr.sh_size.set(1);
    hdr.shdr.sh_addralign.set(E::WORD_SIZE as u64);
    hdr
}

// Program header, a.k.a. segment header. Each entry in the program header
// represents a contiguous region of memory and has attributes such as
// page protection bits. On program startup, the kernel mmap's the file
// contents to memory based on the program header.
#[derive(Debug)]
pub struct OutputPhdr<E: Target> {
    pub hdr: ChunkHeader<E>,
    pub phdrs: Vec<ElfPhdr<E>>,
}

impl<E: Target> OutputPhdr<E> {
    pub fn new(sh_flags: u64) -> Self {
        let mut hdr = ChunkHeader::<E>::new("PHDR", 0, sh_flags);
        hdr.shdr.sh_addralign.set(E::WORD_SIZE as u64);
        Self { hdr, phdrs: Vec::new() }
    }
}

// .gdb_index contains several tables to speed up gdb start-up.
pub fn new_gdb_index<E: Target>() -> ChunkHeader<E> {
    let mut hdr = ChunkHeader::<E>::new(".gdb_index", SHT_PROGBITS, 0);
    hdr.shdr.sh_addralign.set(4);
    hdr
}

fn entry_addr<E: Target>(ctx: &Context<E>) -> u64 {
    if ctx.args.relocatable {
        return 0;
    }
    let sym = &ctx.symbols[ctx.syms.entry];
    if let Some(FileId::Obj(_)) = sym.file() {
        return sym.addr(ctx);
    }
    if !ctx.args.shared {
        warn!("entry symbol is not defined: {sym}");
    }
    0
}

fn write_ehdr<E: Target>(ctx: &Context<E>, buf: &mut [u8]) {
    let mut ehdr = ElfEhdr::<E>::default();
    ehdr.e_ident[..4].copy_from_slice(b"\x7fELF");
    ehdr.e_ident[EI_CLASS as usize] = if E::IS_64 { ELFCLASS64 } else { ELFCLASS32 } as u8;
    ehdr.e_ident[EI_DATA as usize] = if E::IS_LITTLE { ELFDATA2LSB } else { ELFDATA2MSB } as u8;
    ehdr.e_ident[EI_VERSION as usize] = EV_CURRENT as u8;
    ehdr.e_machine.set(E::E_MACHINE as u16);
    ehdr.e_version.set(EV_CURRENT);
    ehdr.e_entry.set(entry_addr(ctx));
    ehdr.e_flags.set(E::eflags(ctx));
    ehdr.e_ehsize.set(size_of::<ElfEhdr<E>>() as u16);

    // If e_shstrndx is too large, a dummy value is set to e_shstrndx.
    // The real value is stored to the zero'th section's sh_link field.
    if let Some(shstrtab) = &ctx.shstrtab {
        ehdr.e_shstrndx.set(if shstrtab.shndx < SHN_LORESERVE {
            shstrtab.shndx as u16
        } else {
            SHN_XINDEX as u16
        });
    }

    ehdr.e_type.set(if ctx.args.relocatable {
        ET_REL
    } else if ctx.args.pie && ctx.args.ttext_segment.is_some() {
        ET_EXEC
    } else if ctx.args.pic {
        ET_DYN
    } else {
        ET_EXEC
    } as u16);

    if let Some(phdr) = &ctx.phdr {
        ehdr.e_phoff.set(phdr.hdr.shdr.sh_offset.get());
        ehdr.e_phentsize.set(size_of::<ElfPhdr<E>>() as u16);
        ehdr.e_phnum.set((phdr.hdr.shdr.sh_size.get() / size_of::<ElfPhdr<E>>() as u64) as u16);
    }

    if let Some(shdr) = &ctx.shdr {
        ehdr.e_shoff.set(shdr.shdr.sh_offset.get());
        ehdr.e_shentsize.set(size_of::<ElfShdr<E>>() as u16);
        // Since e_shnum is a 16-bit integer field, we can't store a very
        // large value there. If it is >65535, the real value is stored to
        // the zero'th section's sh_size field.
        let shnum = shdr.shdr.sh_size.get() / size_of::<ElfShdr<E>>() as u64;
        ehdr.e_shnum.set(if shnum <= u16::MAX as u64 { shnum as u16 } else { 0 });
    }

    ehdr.write(buf);
}

fn write_shdr<E: Target>(ctx: &Context<E>, buf: &mut [u8]) {
    let size = size_of::<ElfShdr<E>>();
    buf.fill(0);

    let mut first = ElfShdr::<E>::default();
    if let Some(shstrtab) = &ctx.shstrtab
        && shstrtab.shndx >= SHN_LORESERVE
    {
        first.sh_link.set(shstrtab.shndx);
    }
    let shnum = buf.len() / size;
    if shnum > u16::MAX as usize {
        first.sh_size.set(shnum as u64);
    }
    first.write(buf);

    for &id in &ctx.chunks {
        let hdr = ctx.chunk_header(id);
        if hdr.shndx != 0 {
            hdr.shdr.write(&mut buf[hdr.shndx as usize * size..]);
        }
    }
}

/// The segment flags a chunk requires.
pub fn to_phdr_flags<E: Target>(ctx: &Context<E>, id: ChunkId) -> u32 {
    // All sections are put into a single RWX segment if --omagic
    if ctx.args.omagic {
        return PF_R | PF_W | PF_X;
    }

    let hdr = ctx.chunk_header(id);
    let write = hdr.shdr.sh_flags.get() & SHF_WRITE as u64 != 0;
    let mut exec = hdr.shdr.sh_flags.get() & SHF_EXECINSTR as u64 != 0;

    // .text is not readable if --execute-only
    if exec && ctx.args.execute_only {
        if write {
            error!("--execute-only is not compatible with writable section: {}", hdr.name);
        }
        return PF_X;
    }

    // .rodata is merged with .text if --no-rosegment
    if !write && !ctx.args.rosegment {
        exec = true;
    }

    PF_R | if write { PF_W } else { 0 } | if exec { PF_X } else { 0 }
}

fn create_phdr<E: Target>(ctx: &Context<E>) -> Vec<ElfPhdr<E>> {
    let mut vec: Vec<ElfPhdr<E>> = Vec::new();

    let define = |vec: &mut Vec<ElfPhdr<E>>, p_type: u32, flags: u32, shdr: &ElfShdr<E>| {
        let mut phdr = ElfPhdr::<E>::default();
        phdr.set_p_type(p_type);
        phdr.set_p_flags(flags);
        phdr.set_p_align(shdr.sh_addralign.get());
        if shdr.sh_type.get() == SHT_NOBITS {
            // p_offset indicates the in-file start offset and is not
            // significant for segments with zero on-file size. We still want to
            // keep it congruent with the virtual address modulo page size
            // because some loaders (at least FreeBSD's) are picky about it.
            phdr.set_p_offset(shdr.sh_addr.get() % ctx.args.page_size);
        } else {
            phdr.set_p_offset(shdr.sh_offset.get());
            phdr.set_p_filesz(shdr.sh_size.get());
        }
        phdr.set_p_vaddr(shdr.sh_addr.get());
        phdr.set_p_paddr(shdr.sh_addr.get());
        if shdr.sh_flags.get() & SHF_ALLOC as u64 != 0 {
            phdr.set_p_memsz(shdr.sh_size.get());
        }
        vec.push(phdr);
    };

    let append = |vec: &mut Vec<ElfPhdr<E>>, shdr: &ElfShdr<E>| {
        let phdr = vec.last_mut().unwrap();
        let align = phdr.p_align().max(shdr.sh_addralign.get());
        phdr.set_p_align(align);
        let memsz = shdr.sh_addr.get() + shdr.sh_size.get() - phdr.p_vaddr();
        phdr.set_p_memsz(memsz);
        if shdr.sh_type.get() != SHT_NOBITS {
            phdr.set_p_filesz(memsz);
        }
    };

    let is_bss = |id: ChunkId| ctx.chunk_header(id).shdr.sh_type.get() == SHT_NOBITS;
    let is_tbss = |id: ChunkId| {
        let shdr = &ctx.chunk_header(id).shdr;
        shdr.sh_type.get() == SHT_NOBITS && shdr.sh_flags.get() & SHF_TLS as u64 != 0
    };
    let is_note = |id: ChunkId| ctx.chunk_header(id).shdr.sh_type.get() == SHT_NOTE;

    // When we are creating PT_LOAD segments, we consider only
    // the following chunks.
    let mut chunks: Vec<ChunkId> = ctx
        .chunks
        .iter()
        .copied()
        .filter(|&id| ctx.chunk_header(id).is_alloc() && !is_tbss(id))
        .collect();

    // The ELF spec says that "loadable segment entries in the program
    // header table appear in ascending order, sorted on the p_vaddr
    // member".
    chunks.sort_by_key(|&id| ctx.chunk_header(id).shdr.sh_addr.get());

    // Create a PT_PHDR for the program header itself.
    if let Some(phdr) = &ctx.phdr
        && phdr.hdr.is_alloc()
    {
        define(&mut vec, PT_PHDR, PF_R, &phdr.hdr.shdr);
    }

    // Create a PT_INTERP.
    if let Some(osec) = &ctx.interp {
        define(&mut vec, PT_INTERP, PF_R, &osec.shdr);
    }

    // Create a PT_NOTE for SHF_NOTE sections.
    let mut i = 0;
    while i < chunks.len() {
        let first = chunks[i];
        i += 1;
        if is_note(first) {
            let flags = to_phdr_flags(ctx, first);
            define(&mut vec, PT_NOTE, flags, &ctx.chunk_header(first).shdr);
            while i < chunks.len() && is_note(chunks[i]) && to_phdr_flags(ctx, chunks[i]) == flags {
                append(&mut vec, &ctx.chunk_header(chunks[i]).shdr);
                i += 1;
            }
        }
    }

    // Create PT_LOAD segments.
    let mut i = 0;
    while i < chunks.len() {
        let first = chunks[i];
        i += 1;
        let flags = to_phdr_flags(ctx, first);
        let first_shdr = &ctx.chunk_header(first).shdr;
        define(&mut vec, PT_LOAD, flags, first_shdr);
        if !ctx.args.nmagic && !ctx.args.omagic {
            let last = vec.last_mut().unwrap();
            let align = last.p_align().max(ctx.args.page_size);
            last.set_p_align(align);
        }

        // Add contiguous ALLOC sections as long as they have the same
        // section flags and there's no on-disk gap in between.
        if !is_bss(first) {
            while i < chunks.len()
                && !is_bss(chunks[i])
                && to_phdr_flags(ctx, chunks[i]) == flags
                && {
                    let shdr = &ctx.chunk_header(chunks[i]).shdr;
                    let offset = shdr.sh_offset.get();
                    let addr = shdr.sh_addr.get();
                    offset.wrapping_sub(first_shdr.sh_offset.get())
                        == addr.wrapping_sub(first_shdr.sh_addr.get())
                }
            {
                append(&mut vec, &ctx.chunk_header(chunks[i]).shdr);
                i += 1;
            }
        }
        while i < chunks.len() && is_bss(chunks[i]) && to_phdr_flags(ctx, chunks[i]) == flags {
            append(&mut vec, &ctx.chunk_header(chunks[i]).shdr);
            i += 1;
        }
    }

    // Create a PT_TLS.
    let is_tls = |id: ChunkId| ctx.chunk_header(id).shdr.sh_flags.get() & SHF_TLS as u64 != 0;
    let mut i = 0;
    while i < ctx.chunks.len() {
        let first = ctx.chunks[i];
        i += 1;
        if is_tls(first) {
            define(&mut vec, PT_TLS, PF_R, &ctx.chunk_header(first).shdr);
            while i < ctx.chunks.len() && is_tls(ctx.chunks[i]) {
                append(&mut vec, &ctx.chunk_header(ctx.chunks[i]).shdr);
                i += 1;
            }
        }
    }

    // Add PT_DYNAMIC
    if let Some(osec) = &ctx.dynamic
        && osec.shdr.sh_size.get() != 0
    {
        let flags = to_phdr_flags(ctx, ChunkId::Dynamic);
        define(&mut vec, PT_DYNAMIC, flags, &osec.shdr);
    }

    // Add PT_GNU_EH_FRAME
    if let Some(osec) = &ctx.eh_frame_hdr {
        define(&mut vec, PT_GNU_EH_FRAME, PF_R, &osec.hdr.shdr);
    }

    // Add PT_GNU_SFRAME
    if ctx.sframe.hdr.shdr.sh_size.get() != 0 && ctx.chunks.contains(&ChunkId::SFrame) {
        define(&mut vec, PT_GNU_SFRAME, PF_R, &ctx.sframe.hdr.shdr);
    }

    // Add PT_GNU_PROPERTY
    if let Some(id) = ctx.find_chunk_by_name(b".note.gnu.property") {
        define(&mut vec, PT_GNU_PROPERTY, PF_R, &ctx.chunk_header(id).shdr);
    }

    // Add PT_GNU_STACK, which is a marker segment that doesn't really
    // contain any segments. It controls executable bit of stack area.
    let mut stack = ElfPhdr::<E>::default();
    stack.set_p_type(PT_GNU_STACK);
    stack.set_p_flags(if ctx.args.z_execstack { PF_R | PF_W | PF_X } else { PF_R | PF_W });
    stack.set_p_memsz(ctx.args.z_stack_size);
    stack.set_p_align(1);
    vec.push(stack);

    // Create a PT_GNU_RELRO.
    if ctx.args.z_relro {
        let mut i = 0;
        while i < chunks.len() {
            let first = chunks[i];
            i += 1;
            let hdr = ctx.chunk_header(first);
            if hdr.is_relro {
                define(&mut vec, PT_GNU_RELRO, PF_R, &hdr.shdr);
                while i < chunks.len() && ctx.chunk_header(chunks[i]).is_relro {
                    append(&mut vec, &ctx.chunk_header(chunks[i]).shdr);
                    i += 1;
                }
                vec.last_mut().unwrap().set_p_align(1);
            }
        }
    }

    // Create a PT_ARM_EXIDX
    if let Some(osec) = &ctx.arm_exidx {
        define(&mut vec, PT_ARM_EXIDX, PF_R, &osec.hdr.shdr);
    }

    // Create a PT_RISCV_ATTRIBUTES
    if let Some(osec) = &ctx.riscv_attributes
        && osec.hdr.shdr.sh_size.get() != 0
    {
        define(&mut vec, PT_RISCV_ATTRIBUTES, PF_R, &osec.hdr.shdr);
    }

    // Create a PT_OPENBSD_RANDOMIZE
    for &id in &ctx.chunks {
        let hdr = ctx.chunk_header(id);
        if hdr.name == b".openbsd.randomdata" {
            define(&mut vec, PT_OPENBSD_RANDOMIZE, PF_R | PF_W, &hdr.shdr);
        }
    }

    // Set p_paddr if --physical-image-base was given. --physical-image-base
    // is typically used in embedded programming to specify the base address
    // of a memory-mapped ROM area. In that environment, paddr refers to a
    // segment's initial location in ROM and vaddr refers to its run-time
    // address.
    //
    // When a device is turned on, it starts executing code at a fixed
    // location in the ROM area. At that location is a startup routine that
    // copies data or code from ROM to RAM before using them.
    //
    // .data must have different paddr and vaddr because ROM is not writable.
    // paddr of .rodata and .text may or may not be equal to vaddr. They can be
    // directly read or executed from ROM, but oftentimes they are copied
    // from ROM to RAM because Flash or EEPROM are usually much slower than
    // DRAM.
    //
    // We want to keep vaddr == paddr for as many segments as possible so
    // that they can be directly read/executed from ROM. If a gap between
    // two segments is twice the page size or larger, we give up and pack
    // segments tightly so that we don't waste too much ROM area.
    if let Some(base) = ctx.args.physical_image_base
        && let Some(first) = vec.iter().position(|p| p.p_type() == PT_LOAD)
    {
        let mut addr = base;
        let mut in_sync = vec[first].p_vaddr() == addr;
        vec[first].set_p_paddr(addr);
        addr += vec[first].p_memsz();

        for p in vec[first + 1..].iter_mut().take_while(|p| p.p_type() == PT_LOAD) {
            if in_sync && addr <= p.p_vaddr() && p.p_vaddr() < addr + ctx.args.page_size * 2 {
                let vaddr = p.p_vaddr();
                p.set_p_paddr(vaddr);
                addr = vaddr + p.p_memsz();
            } else {
                in_sync = false;
                p.set_p_paddr(addr);
                addr += p.p_memsz();
            }
        }
    }

    vec.resize(vec.len() + ctx.args.spare_program_headers.max(0) as usize, ElfPhdr::<E>::default());
    vec
}

/// Recomputes the program header and the TLS layout constants.
pub fn update_phdr<E: Target>(ctx: &mut Context<E>) {
    if ctx.phdr.is_none() {
        return;
    }
    let phdrs = create_phdr(ctx);
    if let Some(phdr) = phdrs.iter().find(|p| p.p_type() == PT_TLS) {
        ctx.tls_begin = phdr.p_vaddr();
        ctx.tp_addr = tls::tp_addr::<E>(phdr);
        ctx.dtp_addr = tls::dtp_addr::<E>(phdr);
    }
    let size = (phdrs.len() * size_of::<ElfPhdr<E>>()) as u64;
    let phdr = ctx.phdr.as_mut().unwrap();
    phdr.hdr.shdr.sh_size.set(size);
    phdr.phdrs = phdrs;
}

/// Updates a chunk's section header for the current layout. Called at
/// least twice: once to size the section, and again after section
/// indices are known.
pub fn update_shdr<E: Target>(ctx: &mut Context<E>, id: ChunkId) {
    match id {
        ChunkId::Output(id) => output_section::update_shdr(ctx, id),
        ChunkId::Phdr => update_phdr(ctx),
        ChunkId::Interp => interp::update_shdr(ctx),
        ChunkId::GotPlt => gotplt::update_shdr(ctx),
        ChunkId::RelPlt => relplt::update_shdr(ctx),
        ChunkId::RelDyn => reldyn::update_shdr(ctx),
        ChunkId::Dynamic => dynamic::update_shdr(ctx),
        ChunkId::Strtab => strtab::update_shdr(ctx),
        ChunkId::Shstrtab => shstrtab::update_shdr(ctx),
        ChunkId::Plt => plt::update_shdr(ctx),
        ChunkId::Symtab => symtab::update_shdr(ctx),
        ChunkId::Dynsym => dynsym::update_shdr(ctx),
        ChunkId::Hash => hash::update_shdr(ctx),
        ChunkId::GnuHash => gnu_hash::update_shdr(ctx),
        ChunkId::EhFrameHdr => eh_frame_hdr::update_shdr(ctx),
        ChunkId::EhFrameReloc => eh_frame_reloc::update_shdr(ctx),
        ChunkId::SFrameReloc => sframe_reloc::update_shdr(ctx),
        ChunkId::Versym => versym::update_shdr(ctx),
        ChunkId::Verneed => verneed::update_shdr(ctx),
        ChunkId::Verdef => verdef::update_shdr(ctx),
        ChunkId::BuildId => build_id::update_shdr(ctx),
        ChunkId::NotePackage => note_package::update_shdr(ctx),
        ChunkId::NoteProperty => note_property::update_shdr(ctx),
        ChunkId::RiscvAttributes => riscv_attributes::update_shdr(ctx),
        ChunkId::ArmExidx => arm_exidx::update_shdr(ctx),
        ChunkId::GnuDebuglink => gnu_debuglink::update_shdr(ctx),
        ChunkId::Reloc(i) => reloc::update_shdr(ctx, i),
        ChunkId::ComdatGroup(i) => comdat_group::update_shdr(ctx, i),
        _ => {}
    }
}

/// Computes a chunk's size from its contents. For output sections this
/// also assigns offsets to the members.
pub fn compute_section_size<E: Target>(ctx: &mut Context<E>, id: ChunkId) {
    match id {
        ChunkId::Output(id) => output_section::compute_section_size(ctx, id),
        ChunkId::Merged(id) => merged::compute_section_size(ctx, id),
        ChunkId::ArmExidx => arm_exidx::compute_section_size(ctx),
        _ => {}
    }
}

/// The number of dynamic relocations a chunk emits.
pub fn num_dynrels<E: Target>(ctx: &Context<E>, id: ChunkId) -> u64 {
    match id {
        ChunkId::Output(id) => output_section::num_dynrels(ctx, id),
        ChunkId::Got => got::num_dynrels(ctx),
        ChunkId::Copyrel => ctx.copyrel.symbols.len() as u64,
        ChunkId::CopyrelRelro => ctx.copyrel_relro.symbols.len() as u64,
        ChunkId::Ppc64Opd => opd::num_dynrels(ctx),
        _ => 0,
    }
}

/// The offsets (relative to the chunk) of base relocations that can be
/// encoded in RELR form, marking them as such.
pub fn relr_offsets<E: Target>(ctx: &mut Context<E>, id: ChunkId) -> Vec<u64> {
    match id {
        ChunkId::Output(id) => output_section::relr_offsets(ctx, id),
        ChunkId::Got => got::relr_offsets(ctx),
        ChunkId::Ppc64Opd => opd::relr_offsets(ctx),
        _ => Vec::new(),
    }
}

/// Writes a chunk's dynamic relocations to its assigned output slots.
pub fn write_dynrels<E: Target>(ctx: &Context<E>, id: ChunkId, out: &mut [ElfRel<E>]) {
    match id {
        ChunkId::Output(id) => output_section::write_dynrels(ctx, id, out),
        ChunkId::Got => got::write_dynrels(ctx, out),
        ChunkId::Copyrel => copyrel::write_dynrels(ctx, &ctx.copyrel, out),
        ChunkId::CopyrelRelro => copyrel::write_dynrels(ctx, &ctx.copyrel_relro, out),
        ChunkId::Ppc64Opd => opd::write_dynrels(ctx, out),
        _ => {}
    }
}

/// Sizes the local symbols a chunk synthesizes.
pub fn compute_symtab_size<E: Target>(ctx: &mut Context<E>, id: ChunkId) {
    match id {
        ChunkId::Output(id) => output_section::compute_symtab_size(ctx, id),
        ChunkId::Got => got::compute_symtab_size(ctx),
        ChunkId::Plt => plt::compute_symtab_size(ctx),
        ChunkId::PltGot => pltgot::compute_symtab_size(ctx),
        _ => {}
    }
}

/// Produces the local symbols a chunk synthesizes.
pub fn populate_symtab<E: Target>(ctx: &Context<E>, id: ChunkId, block: &mut SymtabBlock<'_>) {
    match id {
        ChunkId::Output(id) => output_section::populate_symtab(ctx, id, block),
        ChunkId::Got => got::populate_symtab(ctx, block),
        ChunkId::Plt => plt::populate_symtab(ctx, block),
        ChunkId::PltGot => pltgot::populate_symtab(ctx, block),
        _ => {}
    }
}

/// Writes a chunk's contents into its region of the output file.
///
/// Chunks whose contents spill into other chunks (`.eh_frame` writes the
/// `.eh_frame_hdr` table, `.symtab` writes `.strtab`) are handled by the
/// output file writer, which hands them the extra buffers.
pub fn copy_buf<E: Target>(ctx: &Context<E>, id: ChunkId, buf: &mut [u8]) {
    match id {
        ChunkId::Ehdr => write_ehdr(ctx, buf),
        ChunkId::Shdr => write_shdr(ctx, buf),
        ChunkId::Phdr => {
            let phdrs = &ctx.phdr.as_ref().unwrap().phdrs;
            ElfPhdr::<E>::write_all(phdrs, buf);
        }
        ChunkId::Interp => interp::copy_buf(ctx, buf),
        ChunkId::Got => got::copy_buf(ctx, buf),
        ChunkId::GotPlt => gotplt::copy_buf(ctx, buf),
        ChunkId::RelPlt => relplt::copy_buf(ctx, buf),
        ChunkId::RelDyn => reldyn::copy_buf(ctx, buf),
        ChunkId::RelrDyn => relrdyn::copy_buf(ctx, buf),
        ChunkId::Dynamic => dynamic::copy_buf(ctx, buf),
        ChunkId::Strtab => strtab::copy_buf(ctx, buf),
        ChunkId::Dynstr => dynstr::copy_buf(ctx, buf),
        ChunkId::Hash => hash::copy_buf(ctx, buf),
        ChunkId::GnuHash => gnu_hash::copy_buf(ctx, buf),
        ChunkId::GnuDebuglink => gnu_debuglink::copy_buf(ctx, buf),
        ChunkId::Shstrtab => shstrtab::copy_buf(ctx, buf),
        ChunkId::Plt => plt::copy_buf(ctx, buf),
        ChunkId::PltGot => pltgot::copy_buf(ctx, buf),
        ChunkId::Symtab | ChunkId::SymtabShndx => {}
        ChunkId::Dynsym => dynsym::copy_buf(ctx, buf),
        ChunkId::EhFrame | ChunkId::EhFrameHdr => {}
        ChunkId::EhFrameReloc => {}
        ChunkId::SFrame => sframe::copy_buf(ctx, buf),
        ChunkId::SFrameReloc => sframe_reloc::copy_buf(ctx, buf),
        ChunkId::Copyrel | ChunkId::CopyrelRelro => {}
        ChunkId::Versym => versym::copy_buf(ctx, buf),
        ChunkId::Verneed => verneed::copy_buf(ctx, buf),
        ChunkId::Verdef => verdef::copy_buf(ctx, buf),
        ChunkId::BuildId => build_id::copy_buf(ctx, buf),
        ChunkId::NotePackage => note_package::copy_buf(ctx, buf),
        ChunkId::NoteProperty => note_property::copy_buf(ctx, buf),
        ChunkId::RiscvAttributes => riscv_attributes::copy_buf(ctx, buf),
        ChunkId::ArmExidx => arm_exidx::copy_buf(ctx, buf),
        ChunkId::Ppc64SaveRestore => ppc64_save_restore::copy_buf(ctx, buf),
        ChunkId::Ppc64Opd => opd::copy_buf(ctx, buf),
        ChunkId::GdbIndex | ChunkId::RelroPadding | ChunkId::Placeholder(_) => {}
        ChunkId::Output(id) => output_section::copy_buf(ctx, id, buf),
        ChunkId::Merged(id) => merged::write_to(ctx, id, buf),
        ChunkId::Reloc(_) => {}
        ChunkId::ComdatGroup(i) => comdat_group::copy_buf(ctx, i, buf),
        ChunkId::Compressed(i) => compressed::copy_buf(ctx, i, buf),
    }
}

/// Writes a chunk's contents to a scratch buffer, for compression.
pub fn write_to<E: Target>(ctx: &Context<E>, id: ChunkId, buf: &mut [u8]) {
    match id {
        ChunkId::Output(id) => output_section::write_to(ctx, id, buf),
        ChunkId::Merged(id) => merged::write_to(ctx, id, buf),
        _ => unreachable!("write_to is only for output and merged sections"),
    }
}
